module.exports = {
    QANTAS_API_URL: 'https://www.qantas.com.au/api/airports',
    APP_PORT: 3000
};